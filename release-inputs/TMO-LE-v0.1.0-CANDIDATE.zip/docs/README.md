# TMO-LE v0.1.0 candidate artifacts

This package implements the LE evidence-to-state profile as an engineering/conformance candidate. It does not independently determine guilt, probable cause, reasonable suspicion, criminality, extremist/terrorist classification, liability, or legal authority for adverse government action.

The profile keeps source evidence, fact capture, fact qualification, actor attribution, role assignment, consequences, condition vectors, assessments and legal determinations semantically distinct.
