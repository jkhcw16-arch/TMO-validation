from pathlib import Path
import json
from rdflib import Graph
from rdflib.plugins.sparql.parser import parseQuery
from pyshacl import validate
root=Path(__file__).resolve().parents[1]
ont=Graph().parse(root/'ontology/tmo-le.ttl',format='turtle'); shapes=Graph().parse(root/'shapes/tmo-le.shacl.ttl',format='turtle')
results={'ontology_triples':len(ont),'fixtures':{},'queries':{},'status':'PASS'}
fx=[('valid/reference-case.ttl',True),('invalid/role-without-attribution.ttl',False),('invalid/coordination-without-evidence.ttl',False),('invalid/rights-without-basis.ttl',False)]
for rel,exp in fx:
 g=Graph().parse(root/'fixtures'/rel,format='turtle'); c,_,txt=validate(g,shacl_graph=shapes,ont_graph=ont,inference='rdfs',advanced=True,meta_shacl=True)
 ok=bool(c)==exp; results['fixtures'][rel]={'expected':exp,'actual':bool(c),'pass':ok}
 if not ok: results['status']='FAIL'
g=Graph(); [g.add(t) for t in ont]; data=Graph().parse(root/'fixtures/valid/reference-case.ttl',format='turtle'); [g.add(t) for t in data]
oracles=json.loads((root/'expected/competency-oracles.json').read_text())
for qf,oracle in oracles.items():
 q=(root/'queries'/qf).read_text(); parseQuery(q); r=g.query(q)
 if r.type=='ASK': obs={'ask':bool(r.askAnswer)}; exp={'ask':oracle['ask']}
 else:
  rows=list(r); val=int(rows[0][0]) if rows and len(rows[0]) else 0; obs={'rows':val}; exp={'rows':oracle['rows']}
 ok=obs==exp; results['queries'][qf]={'expected':exp,'actual':obs,'pass':ok,'class':oracle['class']}
 if not ok: results['status']='FAIL'
(root/'validation/TMO-LE-Conformance-Results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2)); raise SystemExit(0 if results['status']=='PASS' else 1)
